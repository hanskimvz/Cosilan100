#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdint.h>

#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    #define close_socket closesocket
    #define SOCKET_ERROR_CODE WSAGetLastError()
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <unistd.h>
    #include <errno.h>
    #include <pthread.h>
    #define SOCKET int
    #define INVALID_SOCKET -1
    #define SOCKET_ERROR -1
    #define close_socket close
    #define SOCKET_ERROR_CODE errno
#endif

#define MAX_PORTS 3
#define BUFFER_SIZE 1024

// # Windows gcc -o tcp_server.exe tcp_server.c -lws2_32
// # Linux gcc -o tcp_server tcp_server.c -pthread


int create_server_socket(int port) {
    SOCKET server_fd;
    struct sockaddr_in server_addr;

    if ((server_fd = socket(AF_INET, SOCK_STREAM, 0)) == INVALID_SOCKET) {
        printf("port %d: socket creation failed\n", port);
        return INVALID_SOCKET;
    }

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(port);

    if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
        printf("port %d: bind failed\n", port);
        close_socket(server_fd);
        return INVALID_SOCKET;
    }

    if (listen(server_fd, 3) < 0) {
        printf("port %d: listening failed\n", port);
        close_socket(server_fd);
        return INVALID_SOCKET;
    }

    printf("port %d listening start\n", port);
    return server_fd;
}


int send_cgi(SOCKET newsockfd, char cgi_str[1024]) {
	int retcode;
	int size;

	size = strlen(cgi_str);
	retcode = send(newsockfd, &size, 4, 0);
	if (retcode < 0) {
		printf("*** ERROR - send() failed1 \n");
		return -1;
	}
	retcode = send(newsockfd, cgi_str, size, 0);
	if (retcode < 0) {
		printf("*** ERROR - send() failed2 \n");
		return -1;
	}
	
	printf("\nsent message(%d) : %s\n", size, cgi_str);
	
	return 0;
	
}

char* receive_stream(SOCKET newsockfd) {
	char in_buff[1440]; 
	char* result;
	unsigned int  size=0, ptr=0;
	unsigned int num = 0;

	if ((size = recv(newsockfd, in_buff, 4,0)) < 0 ) { 
		puts( "Server: readn error1!");
		exit(1);
	}
	num = (in_buff[0]&0xFF) | ((in_buff[1]&0xFF)<<8) | ((in_buff[2]&0xFF)<<16) | ((in_buff[3]&0xFF)<<24);
	
	printf("\nString Length = %d : %02X %02X %02X %02X", num, in_buff[0],in_buff[1],in_buff[2],in_buff[3]);
	
	result = (char*)malloc(sizeof(char)*num);

	while(num > 0) {
		size = recv(newsockfd, in_buff, 1440,0);
		if (size < 0 ) {
			puts( "Server: readn error2!");
			exit(1);
		}
		else if(size == 0) {
			break;
		}
		
		strcpy(result+ptr, in_buff);
		num -= size;
		ptr += 1440;
//		printf("reading newsockfd from Client = %d::%d\n", num, size);
//		printf("Server: Received String = %s \n", in_buff);
		
	}
	printf(":%d\n", strlen(result));
	
	return result;
}


void* process_client(void* arg) {
    SOCKET client_fd = (SOCKET)(intptr_t)arg;
    char buffer[BUFFER_SIZE] = {0};
    char response[BUFFER_SIZE] = {0};
    while(1) {
        memset(buffer, 0, BUFFER_SIZE);
        int recv_size = recv(client_fd, buffer, BUFFER_SIZE, 0);
        if (recv_size > 0) {
            printf("proc_client, received message: %s\n", buffer);
            if (strncmp(buffer, "mac=", 4) == 0) {
                send_message(client_fd, "/nvc-cgi/operator/snapshot.fcgi", response, BUFFER_SIZE);
                printf("send_message, received response: %s\n", response);
            }
        }
    }
    close_socket(client_fd);
    return NULL;
}

int main() {
    int ports[] = {5000, 5001, 5002};  // 사용할 포트들
    SOCKET server_fds[MAX_PORTS];
    fd_set readfds;
    int max_sd = 0;
    
    #ifdef _WIN32
        WSADATA wsaData;
        if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
            printf("WSAStartup failed\n");
            return 1;
        }
    #endif

    // 각 포트별 서버 소켓 생성
    for (int i = 0; i < MAX_PORTS; i++) {
        server_fds[i] = create_server_socket(ports[i]);
        if (server_fds[i] == INVALID_SOCKET) {
            continue;
        }
        if (server_fds[i] > max_sd) {
            max_sd = server_fds[i];
        }
    }

    printf("all ports server running...\n");

    while(1) {
        FD_ZERO(&readfds);
        
        // 모든 서버 소켓을 감시 목록에 추가
        for (int i = 0; i < MAX_PORTS; i++) {
            if (server_fds[i] != INVALID_SOCKET) {
                FD_SET(server_fds[i], &readfds);
            }
        }  
        // 서버 소켓 재생성 시도
        for (int i = 0; i < MAX_PORTS; i++) {
            if (server_fds[i] == INVALID_SOCKET) {
                server_fds[i] = create_server_socket(ports[i]);
                if (server_fds[i] != INVALID_SOCKET) {
                    printf("port %d: server socket recreated\n", ports[i]);
                    if (server_fds[i] > max_sd) {
                        max_sd = server_fds[i];
                    }
                }
            }
        }
        // select로 활성화된 소켓 감지
        if (select(max_sd + 1, &readfds, NULL, NULL, NULL) < 0) {
            printf("select error\n");
            continue;
        }

        // 각 서버 소켓 확인
        for (int i = 0; i < MAX_PORTS; i++) {
            if (server_fds[i] != INVALID_SOCKET && FD_ISSET(server_fds[i], &readfds)) {
                struct sockaddr_in client_addr;
                socklen_t addr_len = sizeof(client_addr);
                SOCKET client_fd;

                client_fd = accept(server_fds[i], (struct sockaddr *)&client_addr, &addr_len);
                if (client_fd < 0) {
                    printf("port %d: accept error\n", ports[i]);
                    continue;
                }

                printf("port %d: client connected\n", ports[i]);
                #ifdef _WIN32
                    CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)process_client, (void*)client_fd, 0, NULL);
                #else
                    pthread_t thread;
                    pthread_create(&thread, NULL, process_client, (void*)(intptr_t)client_fd);
                    pthread_detach(thread);
                #endif

            }
        }
    }

    for (int i = 0; i < MAX_PORTS; i++) {
        if (server_fds[i] != INVALID_SOCKET) {
            close_socket(server_fds[i]);
        }
    }

    #ifdef _WIN32
        WSACleanup();
    #endif

    return 0;
} 