#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "parson.h"

#define CONFIG_FILE "config.json"
#define MAX_STRING_LENGTH 256

int main(){
  JSON_Value *rootValue;	
  JSON_Object *rootObject; 	
  rootValue = json_parse_file(CONFIG_FILE);

  rootObject = json_value_get_object(rootValue); 	
  // printf("Greeting: %s\n", json_object_get_string(rootObject, "Greeting"));	
  // printf("Num: %d\n", (int)json_object_get_number(rootObject, "Num"));	
  // printf("DNum: %.1lf\n", json_object_get_number(rootObject, "DNum")); 	
  // printf("array: ");	
  
  JSON_Object * obj = json_object_get_object (rootObject, "MYSQL");
  int i;
  printf("%s\n", json_object_get_string(obj, "host")); 	


  // JSON_Array *array = json_object_get_array(rootObject, "array");	
  
  // int i;
  // for (i = 0; i < json_array_get_count(array); i++) {		
  //   printf("%d ", (int)json_array_get_number(array, i));	
  // } 	
  
  // printf("\nboolean: %d\n", json_object_get_boolean(rootObject, "boolean")); 	
  json_value_free(rootValue);	
  
  return 0;
}
