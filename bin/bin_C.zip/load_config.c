/****************************************************************************
Copyright (c) 2024, Hans kim(hanskimvz@gmail.com)

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:
1. Redistributions of source code must retain the above copyright
notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
notice, this list of conditions and the following disclaimer in the
documentation and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include "load_config.h"

// #define DEBUG

int load_config() {
    JSON_Value *rootValue;    
    JSON_Object *rootObject;

    // Parse the JSON file
    rootValue = json_parse_file(CONFIG_FILE);
    if (rootValue == NULL) {
        fprintf(stderr, "Error parsing the configuration file.\n");
        return -1;
    }

    rootObject = json_value_get_object(rootValue);
    if (rootObject == NULL) {
        fprintf(stderr, "Error retrieving the root object.\n");
        json_value_free(rootValue);
        return -1;
    }


    JSON_Object *dbObj = json_object_get_object(rootObject, "MONGODB");
    JSON_Object *serverObj = json_object_get_object(rootObject, "SERVER");
    JSON_Object *timezoneObj = json_object_get_object(rootObject, "TIMEZONE");

    if (dbObj == NULL || serverObj == NULL || timezoneObj == NULL) {
        fprintf(stderr, "Error retrieving key sections in the configuration.\n");
        json_value_free(rootValue);
        return -1;
    }

    // DB config
    const char *dbHost = json_object_get_string(dbObj, "host");
    const char *dbUser = json_object_get_string(dbObj, "user");
    const char *dbPassword = json_object_get_string(dbObj, "password");
    const char *dbDb = json_object_get_string(dbObj, "db");
    if (dbHost && dbUser && dbPassword && dbDb) {
        strncpy(config.DB.host, dbHost, sizeof(config.DB.host) - 1);
        strncpy(config.DB.user, dbUser, sizeof(config.DB.user) - 1);
        strncpy(config.DB.password, dbPassword, sizeof(config.DB.password) - 1);
        strncpy(config.DB.db, dbDb, sizeof(config.DB.db) - 1);
        config.DB.port = (int)json_object_get_number(dbObj, "port");
    } 
    else {
        fprintf(stderr, "Error retrieving MySQL configuration fields.\n");
        json_value_free(rootValue);
        return -1;
    }

    // DB table config
    JSON_Object *tableObj = json_object_get_object(dbObj, "tables");
    if (tableObj) {
        strncpy(config.DB.table.common_user, json_object_get_string(tableObj, "common_user"), sizeof(config.DB.table.common_user) - 1);
        strncpy(config.DB.table.common_device, json_object_get_string(tableObj, "common_device"), sizeof(config.DB.table.common_device) - 1);
        strncpy(config.DB.table.count_tenmin, json_object_get_string(tableObj, "count_tenmin"), sizeof(config.DB.table.count_tenmin) - 1);
        strncpy(config.DB.table.count_hour, json_object_get_string(tableObj, "count_hour"), sizeof(config.DB.table.count_hour) - 1);
        strncpy(config.DB.table.count_day, json_object_get_string(tableObj, "count_day"), sizeof(config.DB.table.count_day) - 1);
        strncpy(config.DB.table.count_month, json_object_get_string(tableObj, "count_month"), sizeof(config.DB.table.count_month) - 1);
        strncpy(config.DB.table.count_year, json_object_get_string(tableObj, "count_year"), sizeof(config.DB.table.count_year) - 1);
        strncpy(config.DB.table.web_config, json_object_get_string(tableObj, "web_config"), sizeof(config.DB.table.web_config) - 1);        
        strncpy(config.DB.table.user, json_object_get_string(tableObj, "user"), sizeof(config.DB.table.user) - 1);
        strncpy(config.DB.table.ct_label, json_object_get_string(tableObj, "ct_label"), sizeof(config.DB.table.ct_label) - 1);
        strncpy(config.DB.table.camera, json_object_get_string(tableObj, "camera"), sizeof(config.DB.table.camera) - 1);
        strncpy(config.DB.table.store, json_object_get_string(tableObj, "store"), sizeof(config.DB.table.store) - 1);
        strncpy(config.DB.table.square, json_object_get_string(tableObj, "square"), sizeof(config.DB.table.square) - 1);
        strncpy(config.DB.table.snapshot, json_object_get_string(tableObj, "snapshot"), sizeof(config.DB.table.snapshot) - 1);
    } 
    else {
        fprintf(stderr, "Error retrieving MySQL table configuration.\n");
        json_value_free(rootValue);
        return -1;
    }

    // Server config
    const char *serverHost = json_object_get_string(serverObj, "host");
    if (serverHost) {
        strncpy(config.SERVER.host, serverHost, sizeof(config.SERVER.host) - 1);
        config.SERVER.tlss_port = (int)json_object_get_number(serverObj, "tlss_port");
        config.SERVER.http_port = (int)json_object_get_number(serverObj, "http_port");
        config.SERVER.tcp_port  = (int)json_object_get_number(serverObj, "tcp_port");
    } 
    else {
        fprintf(stderr, "Error retrieving server configuration fields.\n");
        json_value_free(rootValue);
        return -1;
    }

    // Timezone config
    const char *timezoneArea = json_object_get_string(timezoneObj, "area");
    if (timezoneArea) {
        strncpy(config.TIMEZONE.area, timezoneArea, sizeof(config.TIMEZONE.area) - 1);
        config.TIMEZONE.tz_offset = (int)json_object_get_number(timezoneObj, "tz_offset");
    } else {
        fprintf(stderr, "Error retrieving timezone configuration fields.\n");
        json_value_free(rootValue);
        return -1;
    }

    // Free the rootValue
    json_value_free(rootValue);
    return 0;
}

void display_config(){
    printf("\n[DB]\n");
    printf("  host:     %s\n", config.DB.host);
    printf("  port:     %d\n", config.DB.port);
    printf("  user:     %s\n", config.DB.user);
    
    // Warning: Displaying the password is a security risk in real-world applications.
    printf("  password: %s\n", config.DB.password);  
    
    printf("  db:       %s\n", config.DB.db);
    printf("    common_device:       %s\n", config.DB.table.common_device);
    printf("    common_user:         %s\n", config.DB.table.common_user);
    printf("    user:                %s\n", config.DB.table.user);
    printf("    device:              %s\n", config.DB.table.device);
    printf("    count_tenmin:        %s\n", config.DB.table.count_tenmin);
    printf("    count_hour:          %s\n", config.DB.table.count_hour);
    printf("    count_day:           %s\n", config.DB.table.count_day);
    printf("    count_month:         %s\n", config.DB.table.count_month);
    printf("    count_year:          %s\n", config.DB.table.count_year);
    printf("    ct_label:            %s\n", config.DB.table.ct_label);
    printf("    camera:              %s\n", config.DB.table.camera);
    printf("    store:               %s\n", config.DB.table.store);
    printf("    square:              %s\n", config.DB.table.square);
    printf("    snapshot:            %s\n", config.DB.table.snapshot);
    printf("    web_config:          %s\n", config.DB.table.web_config);

    printf("\n[SERVER]\n");
    printf("  host: %s\n", config.SERVER.host);
    printf("  tlss_port: %d\n", config.SERVER.tlss_port);
    printf("  http_port: %d\n", config.SERVER.http_port);
    printf("  tcp_port: %d\n", config.SERVER.tcp_port);
    

    printf("\n[TIMEZONE]\n");
    printf("  area:      %s\n", config.TIMEZONE.area);
    printf("  tz_offset: %d\n", config.TIMEZONE.tz_offset);
}

#ifdef DEBUG
int main(){
    load_config();
    display_config();
    return 0;
}
#endif