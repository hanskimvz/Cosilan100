#include <stdio.h>
#include <string.h> 
#include <stdlib.h>
#include <stdint.h>
#include <errno.h>
#include <time.h>

#ifdef _WIN32
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #include <windows.h>
    #ifdef __GNUC__
        #define close_socket closesocket
    #else
        #pragma comment(lib, "ws2_32.lib")
        #define close_socket closesocket
    #endif
    #define sleep(x) Sleep((x)*1000)
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <unistd.h>
    #include <errno.h>
    #include <pthread.h>
    #define SOCKET int
    #define INVALID_SOCKET -1
    #define SOCKET_ERROR -1
    #define close_socket close
#endif

#include "load_config.h"
#include "proc_mongo.h"

// thread_args 구조체 정의
struct thread_args {
    SOCKET client_fd;
    struct sockaddr_in client_addr;
};


int send_cgi(int newsockfd, char cgi_str[1024]) {
    int retcode;
    uint32_t size;

    size = strlen(cgi_str);
#ifdef _WIN32	
    uint32_t size_network = htonl(size);  // 네트워크 바이트 순서로 변환
    retcode = send(newsockfd, (const char*)&size_network, sizeof(size_network), 0);

#else
    retcode = send(newsockfd, (const char*)&size, sizeof(size), 0);
#endif
    if (retcode < 0) {
        printf("*** ERROR - send() failed1 \n");
        return -1;
    }

    retcode = send(newsockfd, cgi_str, size, 0);
    if (retcode < 0) {
        printf("*** ERROR - send() failed2 \n");
        return -1;
    }
    
    printf("\nsent message(%u) : %s\n", size, cgi_str);
    
    return 0;
}
// #else
// int send_cgi(int sock_fd, char cgi_str[1024]) {
// 	int retcode;
// 	int size;

// 	size = strlen(cgi_str);
// 	retcode = send(sock_fd, &size, 4, 0);
// 	if (retcode < 0) {
// 		printf("*** ERROR - send() failed1 \n");
// 		return -1;
// 	}
// 	retcode = send(sock_fd, cgi_str, size, 0);
// 	if (retcode < 0) {
// 		printf("*** ERROR - send() failed2 \n");
// 		return -1;
// 	}
	
// 	printf("\nsent message(%d) : %s\n", size, cgi_str);
	
// 	return 0;
	
// }
// #endif

char* receive_stream(int newsockfd)
{
	char in_buff[1440]; 
	char* result;
	unsigned int  size=0, ptr=0;
	unsigned int num = 0;

	size = recv(newsockfd, in_buff, 4,0);
	if (size < 0 ) { 
		puts( "Server: readn error1!");
		exit(1);
	}
	num = (in_buff[0]&0xFF) | ((in_buff[1]&0xFF)<<8) | ((in_buff[2]&0xFF)<<16) | ((in_buff[3]&0xFF)<<24);
	
	printf("\nString Length = %d, %d : %02X %02X %02X %02X", size, num, in_buff[0],in_buff[1],in_buff[2],in_buff[3]);
	
	result = (char*)malloc(sizeof(char)*num);

	while(num > 0) {
		size = recv(newsockfd, in_buff, 1440,0);
		if (size < 0 ) {
			puts( "Server: readn error2!");
			exit(1);
		}
		else if(size == 0) {
			break;
		}
		
		strcpy(result+ptr, in_buff);
		num -= size;
		ptr += 1440;
//		printf("reading newsockfd from Client = %d::%d\n", num, size);
//		printf("Server: Received String = %s \n", in_buff);
		
	}
	#ifdef _WIN32
		printf("String Length: %u\n", (unsigned int)strlen(result));
	#else
		printf("String Length: %zu\n", strlen(result));
	#endif
	
	return result;
}

int createServer(int port) {
	int server_fd;
	struct sockaddr_in server_addr;
	
	// Create socket
	server_fd = socket(AF_INET, SOCK_STREAM, 0);
	if (server_fd == 0) {
		perror("Socket creation failed");
		return -1;
	}

	// Set up the server address structure
	server_addr.sin_family = AF_INET;
	server_addr.sin_addr.s_addr = INADDR_ANY;  // Bind to any address
	server_addr.sin_port = htons(port);

	// Bind the socket to the address and port
	if (bind(server_fd, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0) {
		perror("Bind failed");
		close_socket(server_fd);
		return -1;
	}

	// Listen for incoming connections
	if (listen(server_fd, 3) < 0) {
		perror("Listen failed");
		close_socket(server_fd);
		return -1;
	}
	printf("Server is listening on port %d...\n", port);

	return server_fd;
}

int proc_tlss(SOCKET newsockfd) {
	char* temp;
	temp = receive_stream(newsockfd);
	printf("%s", temp);
	
	send_cgi( newsockfd,"/uapi-cgi/param.fcgi?action=list&group=VERSION" );
	temp = receive_stream(newsockfd);
	printf("\n======================\n%s", temp);
	
	// send_cgi( newsockfd,"/uapi-cgi/param.fcgi?action=list&group=BRAND" );
	// temp = receive_stream(newsockfd);
	// printf("\n======================\n%s", temp);
	
	// send_cgi( newsockfd,"/cgi-bin/operator/countreport.cgi?reportfmt=csv&from=now-06:00&to=now&counter=active&sampling=600&order=Descending&value=diff" );
	// temp = receive_stream(newsockfd);
	// printf("\n======================\n%s", temp);

	// send_cgi( newsockfd,"/uapi-cgi/reporthm.cgi?reportfmt=csv&from=yesterday&to=today&table=3&individual=no" );
	// temp = receive_stream(newsockfd);
	// printf("\n======================\n%s", temp);
	
	
	send_cgi(newsockfd,"done\0");
	close_socket( newsockfd );	
	return 0;
}

// proc_tlss 함수의 프로토타입 수정
void* proc_tlss_wrapper(void* arg) {
    struct thread_args* args = (struct thread_args*)arg;
    proc_tlss(args->client_fd);
    close_socket(args->client_fd);
    free(arg);
    return NULL;
}

int main (void) {
	int server_fd = INVALID_SOCKET;
	time_t timestamp;
	char date_str[20];
	load_config();

	while(1) {
		if (server_fd == INVALID_SOCKET) {
			server_fd = createServer(config.SERVER.tlss_port);
		}

		struct sockaddr_in client_addr;
		socklen_t addr_len = sizeof(client_addr);
		SOCKET client_fd;

		client_fd = accept(server_fd, (struct sockaddr *)&client_addr, &addr_len);
		if (client_fd == INVALID_SOCKET) {
			perror("Failed to accept client");
			sleep(1);
			continue;
		}
		timestamp = time(NULL) + config.TIMEZONE.tz_offset;
		strftime(date_str, sizeof(date_str), "%Y-%m-%d %H:%M:%S", gmtime(&timestamp));
		printf("Client connected ... %s\n", date_str); 

		// thread_args 구조체 할당 및 초기화
		struct thread_args* args = malloc(sizeof(struct thread_args));
		if (args == NULL) {
			perror("Failed to allocate memory for thread args");
			close_socket(client_fd);
			continue;
		}
		args->client_fd = client_fd;
		args->client_addr = client_addr;

		#ifdef _WIN32
			CreateThread(NULL, 0, (LPTHREAD_START_ROUTINE)proc_tlss_wrapper, args, 0, NULL);
		#else
			pthread_t thread_id;
			if (pthread_create(&thread_id, NULL, proc_tlss_wrapper, args) != 0) {
				perror("Failed to create thread");
				free(args);
				close_socket(client_fd);
				continue;
			}
			pthread_detach(thread_id);
		#endif
	}

	if (server_fd != INVALID_SOCKET) {
		close_socket(server_fd);
	}
	

	printf("Connection closed, server shutting down...\n");

	return 0;
}


