#include <stdio.h>
#include <time.h>

int main() {
    // Example UNIX timestamp (seconds since Jan 1, 1970)
    // time_t timestamp = 1728172800;  // Example timestamp
    int ts = 1728172800;  // Example timestamp
    time_t timestamp = ts;  // Example timestamp

    // Convert the timestamp to local time (broken-down time)
    struct tm *local_time = localtime(&timestamp);

    // Create a buffer to hold the formatted date/time string
    char date_str[100];

    // Format the time as "YYYY-MM-DD HH:MM:SS"
    strftime(date_str, sizeof(date_str), "%Y-%m-%d %H:%M:%S", local_time);

    // Output the formatted date/time
    printf("Converted Date and Time: %s\n", date_str);

    return 0;
}