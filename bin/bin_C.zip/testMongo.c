#include <libmongoc-1.0/mongoc.h>
#include <libbson-1.0/bson.h>
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

// MongoDB 연결 정보
#define MONGODB_URI      "mongodb://localhost:5090"
#define DATABASE_NAME    "userdb"
#define COLLECTION_NAME  "users"

// 사용자 구조체
typedef struct {
    char* username;
    char* email;
    char* password;
    char* full_name;
    int age;
    bool is_active;
} User;

// MongoDB 연결 함수
mongoc_collection_t* connect_to_mongodb() {
    mongoc_client_t* client;
    mongoc_collection_t* collection;
    
    // MongoDB C Driver 초기화
    mongoc_init();
    
    // MongoDB 클라이언트 생성
    client = mongoc_client_new(MONGODB_URI);
    if (!client) {
        fprintf(stderr, "Failed to create MongoDB client\n");
        return NULL;
    }
    
    // 컬렉션 가져오기
    collection = mongoc_client_get_collection(client, DATABASE_NAME, COLLECTION_NAME);
    return collection;
}

// 1. 사용자 생성 함수
bool create_user(mongoc_collection_t* collection, User* user) {
    bson_error_t error;
    bson_t* doc;
    bool success;
    
    doc = bson_new();
    BSON_APPEND_UTF8(doc, "username", user->username);
    BSON_APPEND_UTF8(doc, "email", user->email);
    BSON_APPEND_UTF8(doc, "password", user->password);
    BSON_APPEND_UTF8(doc, "fullName", user->full_name);
    BSON_APPEND_INT32(doc, "age", user->age);
    BSON_APPEND_BOOL(doc, "isActive", user->is_active);
    BSON_APPEND_DATE_TIME(doc, "createdAt", (int64_t)time(NULL) * 1000);
    
    success = mongoc_collection_insert_one(collection, doc, NULL, NULL, &error);
    
    if (!success) {
        fprintf(stderr, "Error: %s\n", error.message);
    } else {
        printf("Successfully created user\n");
    }
    
    bson_destroy(doc);
    return success;
}

// 2. 사용자 조회 함수
void find_user_by_username(mongoc_collection_t* collection, const char* username) {
    bson_t* query;
    mongoc_cursor_t* cursor;
    const bson_t* doc;
    char* str;
    
    query = bson_new();
    BSON_APPEND_UTF8(query, "username", username);
    
    cursor = mongoc_collection_find_with_opts(collection, query, NULL, NULL);
    
    while (mongoc_cursor_next(cursor, &doc)) {
        str = bson_as_canonical_extended_json(doc, NULL);
        printf("Found user: %s\n", str);
        bson_free(str);
    }
    
    bson_destroy(query);
    mongoc_cursor_destroy(cursor);
}

// 3. 사용자 정보 업데이트 함수
bool update_user(mongoc_collection_t* collection, const char* username, const char* new_full_name, int new_age) {
    bson_t* query;
    bson_t* update;
    bson_t* set;
    bson_error_t error;
    bool success;
    
    query = bson_new();
    update = bson_new();
    set = bson_new();
    
    BSON_APPEND_UTF8(query, "username", username);
    BSON_APPEND_UTF8(set, "fullName", new_full_name);
    BSON_APPEND_INT32(set, "age", new_age);
    BSON_APPEND_DOCUMENT(update, "$set", set);
    
    success = mongoc_collection_update_one(collection, query, update, NULL, NULL, &error);
    
    if (!success) {
        fprintf(stderr, "Error: %s\n", error.message);
    } else {
        printf("Successfully updated user\n");
    }
    
    bson_destroy(query);
    bson_destroy(update);
    bson_destroy(set);
    return success;
}

// 4. 사용자 삭제 함수
bool delete_user(mongoc_collection_t* collection, const char* username) {
    bson_t* query;
    bson_error_t error;
    bool success;
    
    query = bson_new();
    BSON_APPEND_UTF8(query, "username", username);
    
    success = mongoc_collection_delete_one(collection, query, NULL, NULL, &error);
    
    if (!success) {
        fprintf(stderr, "Error: %s\n", error.message);
    } else {
        printf("Successfully deleted user\n");
    }
    
    bson_destroy(query);
    return success;
}

// 메모리 정리 함수
void cleanup_mongodb(mongoc_collection_t* collection) {
    mongoc_collection_destroy(collection);
    mongoc_cleanup();
}

// 메인 함수 예제
int main() {
    mongoc_collection_t* collection = connect_to_mongodb();
    if (!collection) {
        return 1;
    }
    
    // 새 사용자 생성
    User new_user = {
        .username = "hong",
        .email = "hong@example.com",
        .password = "password123",
        .full_name = "홍길동",
        .age = 30,
        .is_active = true
    };
    
    // CRUD 작업 테스트
    create_user(collection, &new_user);
    find_user_by_username(collection, "hong");
    update_user(collection, "hong", "홍길동2", 31);
    find_user_by_username(collection, "hong");
    delete_user(collection, "hong");
    
    // 정리
    cleanup_mongodb(collection);
    return 0;
}