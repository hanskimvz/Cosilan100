#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
    #ifndef _WIN32_WINNT
    #define _WIN32_WINNT 0x0600
    #endif
    #define WINVER 0x0600
    #include <winsock2.h>
    #include <ws2tcpip.h>
    #pragma comment(lib, "ws2_32.lib")
    #define SOCKET_ERROR_CODE WSAGetLastError()
    #define SOCKET_TIMEOUT WSAETIMEDOUT
    #define close_socket closesocket
    #define init_socket() WSAStartup(MAKEWORD(2, 2), &wsaData)
    #define cleanup_socket() WSACleanup()
#else
    #include <sys/socket.h>
    #include <netinet/in.h>
    #include <arpa/inet.h>
    #include <unistd.h>
    #include <errno.h>
    #define SOCKET int
    #define INVALID_SOCKET -1
    #define SOCKET_ERROR -1
    #define BOOL int
    #define TRUE 1
    #define SOCKET_ERROR_CODE errno
    #define SOCKET_TIMEOUT EAGAIN
    #define close_socket close
    #define init_socket() 0
    #define cleanup_socket()
#endif

#define SSDP_ADDR "239.255.255.250"
#define SSDP_PORT 1900
#define BUFFER_SIZE 4096
// gcc -o upnp_discovery.exe upnp_discovery.c -lws2_32
// gcc -o upnp_discovery.exe upnp_discovery.c -lws2_32


int main() {
    const char *ssdp_discovery_msg = 
        "M-SEARCH * HTTP/1.1\r\n"
        "HOST: 239.255.255.250:1900\r\n"
        "MAN: \"ssdp:discover\"\r\n"
        "MX: 3\r\n"
        "ST: ssdp:all\r\n"
        "\r\n";    

    WSADATA wsaData;
    SOCKET sock;
    struct sockaddr_in send_addr, recv_addr;
    char buffer[BUFFER_SIZE];
    int recv_len, addr_len;
    char devices[100][INET_ADDRSTRLEN];
    int device_count = 0;
    
    // Winsock 초기화
    if (WSAStartup(MAKEWORD(2, 2), &wsaData) != 0) {
        printf("WSAStartup failed\n");
        return 1;
    }

    // UDP 소켓 생성
    sock = socket(AF_INET, SOCK_DGRAM, IPPROTO_UDP);
    if (sock == INVALID_SOCKET) {
        printf("socket creation failed\n");
        WSACleanup();
        return 1;
    }

    // 소켓 설정
    BOOL broadcast = TRUE;
    if (setsockopt(sock, SOL_SOCKET, SO_BROADCAST, (char*)&broadcast, sizeof(broadcast)) < 0) {
        printf("setsockopt SO_BROADCAST failed\n");
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    // 타임아웃 설정 (5초)
    struct timeval tv;
    tv.tv_sec = 30;
    tv.tv_usec = 0;
    if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&tv, sizeof(tv)) < 0) {
        printf("setsockopt SO_RCVTIMEO failed\n");
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    // 멀티캐스트 주소 설정
    memset(&send_addr, 0, sizeof(send_addr));
    send_addr.sin_family = AF_INET;
    send_addr.sin_port = htons(SSDP_PORT);
    send_addr.sin_addr.s_addr = inet_addr(SSDP_ADDR);

    // SSDP 검색 메시지 전송
    printf("searching for UPnP devices...\n");
    if (sendto(sock, ssdp_discovery_msg, strlen(ssdp_discovery_msg), 0,
               (struct sockaddr*)&send_addr, sizeof(send_addr)) == SOCKET_ERROR) {
        printf("send message failed\n");
        closesocket(sock);
        WSACleanup();
        return 1;
    }

    // 응답 수신
    addr_len = sizeof(recv_addr);
    while (1) {
        // 응답 대기 시간을 30초로 설정
        struct timeval long_timeout;
        long_timeout.tv_sec = 30;
        long_timeout.tv_usec = 0;
        if (setsockopt(sock, SOL_SOCKET, SO_RCVTIMEO, (char*)&long_timeout, sizeof(long_timeout)) < 0) {
            printf("setsockopt SO_RCVTIMEO failed\n");
            closesocket(sock);
            WSACleanup();
            return 1;
        }
        recv_len = recvfrom(sock, buffer, BUFFER_SIZE - 1, 0, (struct sockaddr*)&recv_addr, &addr_len);
        
        if (recv_len == SOCKET_ERROR) {
            if (WSAGetLastError() == WSAETIMEDOUT) {
                printf("\nsearch complete\n");
                break;
            }
            printf("receive error\n");
            break;
        }

        buffer[recv_len] = '\0';
        char ip_str[INET_ADDRSTRLEN];
        strcpy(ip_str, inet_ntoa(recv_addr.sin_addr));
        // printf("\nfound device (IP: %s):\n", ip_str);
        
        int found = 0;
        for (int i = 0; i < device_count; i++) {
            if (strcmp(devices[i], ip_str) == 0) {
                found = 1;
                break;
            }
        }
        if (!found) {
            strcpy(devices[device_count], ip_str);
            printf("devices[%d]: %s\n", device_count, devices[device_count]);
            device_count++;
        }
        
        // printf("------------------------\n");
        // printf("%s\n", buffer);
        // printf("------------------------\n");
    }

    closesocket(sock);
    WSACleanup();
    return 0;
} 