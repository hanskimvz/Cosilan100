# Copyright (c) 2024, Hans kim

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in the
# documentation and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os, time, sys
import base64, json
import threading
import socket
import struct
import pymysql
import random

from functions import (MYSQL, TZ_OFFSET, SERVER_HOST, SERVER_PORT, dbconMaster)

# import configparser

# config_object = configparser.ConfigParser()
# with open ('config.ini', 'r') as f:
#   config_object.read_file(f)
# output_dict = dict()
# sections=config_object.sections()
# for section in sections:
#     items=config_object.items(section)
#     output_dict[section]=dict(items)
# print(output_dict)
# MYSQL = output_dict['MYSQL']
# HOST = output_dict['SERVER']['host']
# PORT = output_dict['SERVER']['port']
# TZ_OFFSET = int(output_dict['TIMEZONE']['tz_offset'])
# del(output_dict)

# print (HOST)
# print (PORT)

# HOST = ''
# PORT = 5004

# sys.exit()
# MYSQL = {
#   'host': 'localhost',
#   'user': 'gas_user',
#   'password': '13579',
#   'db' : 'gas_demo',
#   'charset' : 'utf8',
#   'port': 3306,
#   'common_device' : 'gas_common.device',
#   'custom_data': 'gas_data'
# }
# TZ_OFFSET =  3600*9
# def dbconMaster(host = '', user = '', password = '', db = '', charset ='', port=0): #Mysql
# 	if not host :
# 		host = str(MYSQL['host'])
# 	if not user:
# 		user = str(MYSQL['user'])
# 	if not password :
# 		password = str(MYSQL['password'])
# 	if not db:
# 		db = str(MYSQL['db'])
# 	if not charset:
# 		charset = str(MYSQL['charset'])
# 	if not port:
# 		port = int(MYSQL['port'])


# 	try:
# 		dbcon = pymysql.connect(host=host, user=str(user), password=str(password),  charset=charset, port=int(port))
# 	# except pymysql.err.OperationalError as e :
# 	except Exception as e :
# 		print ('dbconerr', str(e))
# 		return None
	
# 	return dbcon

def dateTss(tss):
    # tm_year=2021, tm_mon=3, tm_mday=22, tm_hour=21, tm_min=0, tm_sec=0, tm_wday=0, tm_yday=81, tm_isdst=-1
    year = int(tss.tm_year)
    month = int(tss.tm_mon) 
    day = int(tss.tm_mday)
    hour = int(tss.tm_hour)
    min = int(tss.tm_min)
    wday = int((tss.tm_wday+1)%7)
    week = int(time.strftime("%U", tss))

    return (year, month, day, hour, min, wday, week)

def replyPacket(rc, uid, interval, count, min_t, max_t):
    ts = int(time.time())
    n_ts = ts + interval
    print ('n_ts=%d' %n_ts)

    data = bytearray(struct.pack('B', rc))
    data += bytes(uid.encode())
    data += bytearray(struct.pack('>I', ts))
    data += bytearray(struct.pack('>I', n_ts))
    data += bytearray(struct.pack('>I', count))
    data += bytearray(struct.pack('>H', min_t))
    data += bytearray(struct.pack('>H', max_t))

    for i in range(len(data), 32):
      data += bytearray(struct.pack('B',255))
    
    return data

def praseRecvData(packets):
  print(len(packets), packets)
  eid = packets[0]
  uid = packets[1:9].decode()

  counts =  list()
  for i in range(9, 24*8+9, 8):
    ts = packets[i]<<24   | packets[i+1]<<16 | packets[i+2]<<8 | packets[i+3]
    mt = packets[i+4]<<24 | packets[i+5]<<16 | packets[i+6]<<8 | packets[i+7]
    dt = time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts+TZ_OFFSET)) if ts else 0
    counts.append((ts, mt, dt))

  bat = packets[201]
  uptime = packets[202]<<24 | packets[203]<<16 | packets[204]<<8 | packets[205]

  arr = {
    'eid': eid,
    'uid': uid,
    'counts': counts,
    'bat': bat,
    'uptime': uptime
  }

  print ("eid = %02X" %eid)
  print ("uid = %s" %uid)
  print ("meter data:")
  for ts, mt, dt in counts:
    print ("%d: %d, %s" %(ts, mt, dt) )
  print ("bat = %d" %packets[201])
  print ("upt = %d" %(packets[202]<<24 | packets[203]<<16 | packets[204]<<8 | packets[205]))
  
  return arr


def procPacket(arr):
  dbCon = dbconMaster()
  ts_now = int(time.time())
  with dbCon.cursor(pymysql.cursors.DictCursor) as cur:
    sq = "select pk from " + MYSQL['common_device'] + " where device_uid = '%s'" %arr['uid']
    cur.execute(sq)
    if not cur.fetchone():
      sq = " insert into " + MYSQL['common_device'] + "(device_uid, minimum, maximum, uptime, battery, initial_access, ref_interval) values('%s', 1, 255, %d, %d, '%s', 60)" %(arr['uid'], arr['uptime'], arr['bat'], time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts_now+TZ_OFFSET)))     
      # print (sq)
      cur.execute(sq)
      dbCon.commit()
    
    sq = "update " + MYSQL['common_device'] + " set uptime=%d, battery=%d, last_access='%s', last_timestamp=%d, last_count=%d, counts='%s', status=0 where device_uid = '%s'"  %(arr['uptime'], arr['bat'], time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(ts_now+TZ_OFFSET)), max([ts for ts, mt, dt  in arr['counts']]), max([mt for ts, mt, dt  in arr['counts']]), json.dumps(arr['counts']), arr['uid'])
    # print (sq)
    cur.execute(sq)
    dbCon.commit()

    sq = "select device_uid, minimum, maximum, ref_interval, db_name, last_count, flag from " + MYSQL['common_device'] + " where device_uid = '%s'" %arr['uid']
    # print (sq)
    cur.execute(sq)
    row = cur.fetchone()
    # print(row)
    arr['minimum']  = row['minimum']
    arr['maximum']  = row['maximum']
    arr['interval'] = row['ref_interval']
    arr['db_name']  = row['db_name']
    arr['flag']     = row['flag']
    arr['last_count'] = row['last_count']
    arr['rc'] = 200


    arr_sq = list()
    sq = "show databases like '%s'" %arr['db_name']
    cur.execute(sq)
    if cur.fetchone():
      sq = "show tables from %s like '%s'" %(arr['db_name'], MYSQL['custom_data'])
      cur.execute(sq)
      if cur.fetchone():
        for ts, mt, dt in arr['counts']:
          if not ts :
            continue
            
          sq = "select pk from " + arr['db_name'] + "." + MYSQL['custom_data'] + " where uid='%s' and timestamp = %d " %(arr['uid'], ts)
          cur.execute(sq)
          if cur.rowcount:
            continue
          tss = time.gmtime(ts + TZ_OFFSET)
          print (ts, mt, time.strftime("%Y-%m-%d %H:%M:%S", tss))
          year, month, day, hour, min, wday, week = dateTss(tss)      
          arr_sq.append("insert into  " + arr['db_name'] + "." + MYSQL['custom_data'] + "(uid, timestamp, year, month, day, hour, wday, week, counter_val, flag) values('%s', %d, %d, %d, %d, %d, %d, %d, %d, 'n') " %(arr['uid'], ts, year, month, day, hour, wday, week, mt) )

    for sq in arr_sq:
      print (sq)
      cur.execute(sq)
    dbCon.commit()
    # # print (arr_sq)
    # arr['rc'] = 200
    # print (arr)
  return arr


def procDB():
  dbCon = dbconMaster()
  ts_now = int(time.time())
  arr_sq = []
  with dbCon.cursor(pymysql.cursors.DictCursor) as cur:
    sq = "select device_uid, db_name, counts from " + MYSQL['common_device'] + " where flag='y' and status=0 order by last_timestamp asc limit 100"
    # print (sq)
    cur.execute(sq)
    rows = cur.fetchall()
    for row in rows:
      for ts, mt, dt in arr['counts']:
        if not ts :
          continue
          
        sq = "select pk from " + row['db_name'] + "." + MYSQL['custom_data'] + " where uid='%s' and timestamp = %d " %(row['device_uid'], ts)
        cur.execute(sq)
        if cur.rowcount:
          continue
        tss = time.gmtime(ts + TZ_OFFSET)
        year, month, day, hour, min, wday, week = dateTss(tss)      
        arr_sq.append("insert into  " + arr['db_name'] + "." + MYSQL['custom_data'] + "(uid, timestamp, year, month, day, hour, wday, week, counter_val, flag) values('%s', %d, %d, %d, %d, %d, %d, %d, %d, 'n') " %(arr['uid'], ts, year, month, day, hour, wday, week, mt) )

    if(arr_sq) :        
      for sq in arr_sq:
        print (sq)
        cur.execute(sq)
      dbCon.commit()

def recv_client_thread(conn):
    data = conn.recv(256)
    print (data)
    if data[0] == 0xA0: # normal
      arr = procPacket(praseRecvData(data))
      data = replyPacket(arr['rc'], arr['uid'], arr['interval'], arr['last_count'], arr['minimum'], arr['maximum'])
      print (len(data))
      print (data)
      conn.send(data)
    elif data[0]==0xB0:
      pass
    
    elif  data[0] == 0xE0:
      pass

    elif  data[0] == 0xE1: #init 
      pass

    conn.close()


class thRecv(threading.Thread):
    def __init__(self):
        threading.Thread.__init__(self, name='RECV')
        self.running = True
        self.daemon = True
        self.i = 0
        self.last = 0
        
    def run(self):
        str_s = "=====  Starting RECV Counting  ====="
        print (str_s)
        try:
            self.s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        except socket.error as  msg:
            log.critical("Could not create socket. Error Code: {0}, Error: {1}".format(str(msg[0], msg[1])))
            return False

        try:
            self.s.bind((SERVER_HOST, int(SERVER_PORT)))
        
        except socket.error as msg:
            print ("RECV: Bind Failed. Error: {0}".format(str(msg)))
            self.s.close()
            return False

        self.s.listen(30) 
        print("RECV Engine: Listening...") 

        while self.running:
            self.conn, self.addr = self.s.accept()
            print ("RECV: %s:%s connected, %d" %(self.addr[0], str(self.addr[1]), self.i))
            self.t0 = threading.Thread(target=recv_client_thread, args=(self.conn, ))
            self.t0.start()
            
            self.i += 1
            self.last = int(time.time())

        self.s.close()
        str_s = "Stopping RECV Counting"
        print(str_s)

    def stop(self):
        self.running = False

def mkPseduo():
    ts = 1709218800 #3/1
    mt = 100
    dbCon = dbconMaster()
    with dbCon:
      cur = dbCon.cursor(pymysql.cursors.DictCursor)    
      while True:
        tss = time.gmtime(ts + TZ_OFFSET)
        # print (ts, time.strftime("%Y-%m-%d %H:%M:%S", tss))
        year, month, day, hour, min, wday, week = dateTss(tss)
        if (hour >=7 and hour <= 9) or ( hour >=18 and hour <=20 ):
          mt += random.randint(5,9)
        else:
          mt += random.randint(0,4)
        sq = "insert into  " + "gas_demo" + "." + MYSQL['custom_data'] + "(uid, timestamp, year, month, day, hour, wday, week, counter_val, flag) values('%s', %d, %d, %d, %d, %d, %d, %d, %d, 'n') " %('12345678', ts, year, month, day, hour, wday, week, mt) 
        print (sq)
        cur.execute(sq)
        ts += 3600
        if ts >= int(time.time()):
          break
      dbCon.commit()

if __name__ == '__main__':
    # mkPseduo()
    # arr= {'uid':'12345678', 'uptime':1000, 'bat':50,
    # 'counts': [
    #   (1727244000, 16423, '2024-09-25 06:00:00'),
    #   (1727247600, 16426, '2024-09-25 07:00:00'),
    #   (1727251200, 16431, '2024-09-25 08:00:00'),
    #   (1727254800, 16431, '2024-09-25 09:00:00'),
    #   (1727258400, 16436, '2024-09-25 10:00:00'),
    #   (1727262000, 16436, '2024-09-25 11:00:00'),
    #   (1727265600, 16440, '2024-09-25 12:00:00'),
    #   (1727269200, 16444, '2024-09-25 13:00:00'),
    #   (1727272800, 16450, '2024-09-25 14:00:00'),
    #   (1727276400, 16456, '2024-09-25 15:00:00'),
    #   (1727280000, 16459, '2024-09-25 16:00:00'),
    #   (1727283600, 16465, '2024-09-25 17:00:00'),
    #   (1727287200, 16466, '2024-09-25 18:00:00'),
    #   (1727290800, 16472, '2024-09-25 19:00:00'),
    #   (1727294400, 16477, '2024-09-25 20:00:00'),
    #   (1727298000, 16481, '2024-09-25 21:00:00'),
    #   (1727301600, 16486, '2024-09-25 22:00:00'),
    #   (1727305200, 16492, '2024-09-25 23:00:00'),
    #   (1727308800, 16495, '2024-09-26 00:00:00'),
    #   (1727312400, 16501, '2024-09-26 01:00:00'),
    #   (0, 0, '1970-01-01 00:00:00'),
    #   (0, 0, '1970-01-01 00:00:00'),
    #   (0, 0, '1970-01-01 00:00:00'),
    #   (0, 0, '1970-01-01 00:00:00'),
    # ]
    # }
    # procPacket(arr)
    tc = thRecv()
    tc.start()
    while True:
      # procDB()
      time.sleep(10)