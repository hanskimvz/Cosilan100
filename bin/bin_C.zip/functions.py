# Copyright (c) 2022, Hans kim

# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions are met:
# 1. Redistributions of source code must retain the above copyright
# notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
# notice, this list of conditions and the following disclaimer in the
# documentation and/or other materials provided with the distribution.

# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
# CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
# INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
# MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
# DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR
# CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
# SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
# BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
# SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
# INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
# WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
# NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
# OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

import os, time, sys
# from http.client import HTTPConnection
import socket
import re, base64, struct
# from urllib.parse import urlparse, parse_qsl, unquote
import threading
import pymysql
import logging, logging.handlers
import sqlite3
import signal
import json
import requests
from requests.auth import HTTPBasicAuth, HTTPDigestAuth
import optparse


import configparser

config_object = configparser.ConfigParser()
with open ('config.ini', 'r') as f:
  config_object.read_file(f)
output_dict = dict()
sections=config_object.sections()
for section in sections:
    items=config_object.items(section)
    output_dict[section]=dict(items)
# print(output_dict)
MYSQL = output_dict['MYSQL']
HTTP_HOST = output_dict['HTTP_SERVER']['host']
HTTP_PORT = int(output_dict['HTTP_SERVER']['port'])
SERVER_HOST = output_dict['SERVER']['host']
SERVER_PORT = int(output_dict['SERVER']['port'])

TZ_OFFSET = int(output_dict['TIMEZONE']['tz_offset'])
del(output_dict)



def dbconMaster(host = '', user = '', password = '', db = '', charset ='', port=0): #Mysql
	if not host :
		host = str(MYSQL['host'])
	if not user:
		user = str(MYSQL['user'])
	if not password :
		password = str(MYSQL['password'])
	if not db:
		db = str(MYSQL['db'])
	if not charset:
		charset = str(MYSQL['charset'])
	if not port:
		port = int(MYSQL['port'])


	try:
		dbcon = pymysql.connect(host=host, user=str(user), password=str(password),  charset=charset, port=int(port))
	# except pymysql.err.OperationalError as e :
	except Exception as e :
		print ('dbconerr', str(e))
		return None
	
	return dbcon